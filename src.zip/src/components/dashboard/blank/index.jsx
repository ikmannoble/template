import React from 'react';

export default function Blank() {
  return (
    //   ignore style height
    <div className="container-full" style={{ height: '100vh' }}>
      <h1>Hey</h1>
    </div>
  );
}
