import React from 'react';
import { Link } from 'react-router-dom';

export default function SideBarFooter() {
  return (
    <>
      {/* <!-- item--> */}
      <Link
        to="javascript:void(0)"
        className="link"
        data-toggle="tooltip"
        title=""
        data-original-title="Settings"
        aria-describedby="tooltip92529"
      >
        <span className="icon-Settings-2"></span>
      </Link>
      {/* <!-- item--> */}
      <Link
        to="mailbox.html"
        className="link"
        data-toggle="tooltip"
        title=""
        data-original-title="Email"
      >
        <span className="icon-Mail"></span>
      </Link>
      {/* <!-- item--> */}
      <Link
        to="javascript:void(0)"
        className="link"
        data-toggle="tooltip"
        title=""
        data-original-title="Logout"
      >
        <span className="icon-Lock-overturning">
          <span className="path1"></span>
          <span className="path2"></span>
        </span>
      </Link>
    </>
  );
}
