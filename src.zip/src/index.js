import React, { Fragment } from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import App from './App';
import AppLayout from './components/AppLayout';
import Auth from './components/auth/Auth';
import Home from './components/dashboard/home';
import Blank from './components/dashboard/blank';

//firebase Auth
function Root() {
  return (
    <React.StrictMode>
      <BrowserRouter basename={'/'}>
        <Switch>
          <Fragment>
            <Auth />
            <AppLayout path="/home" exact>
              <Home />
            </AppLayout>
            <AppLayout path="/blank" exact>
              <Blank />
            </AppLayout>
          </Fragment>
        </Switch>
      </BrowserRouter>
    </React.StrictMode>
  );
}

ReactDOM.render(<Root />, document.getElementById('root'));
